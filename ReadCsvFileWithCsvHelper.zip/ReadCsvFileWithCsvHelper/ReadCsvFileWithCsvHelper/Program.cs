﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadCsvFileWithCsvHelper
{
    class Program
    {
        static void Main(string[] args)
        {
            string URL = " https://support.spatialkey.com/wp-content/uploads/2021/02/TechCrunchcontinentalUSA.csv";
            ReadCSV readCSV = new ReadCSV();
            readCSV.URL = URL;

            IEnumerable<TechCrunchcontinentalUSA> techCrunchcontinentalUSAs = readCSV.ReadCSVData();
            foreach(TechCrunchcontinentalUSA techCrunchcontinentalUSA in techCrunchcontinentalUSAs)
            {
                Console.WriteLine(techCrunchcontinentalUSA.company);
            }
            Console.ReadLine();
        }
    }
}

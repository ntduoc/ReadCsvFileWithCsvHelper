﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ReadCsvFileWithCsvHelper
{
    class ReadCSV
    {
        private string url;
        public string URL
        {
            get
            {
                return url;
            }
            set
            {
                url = value;
            }
        }
        public ReadCSV(string url)
        {
            this.url = url;
        }
        public ReadCSV()
        {
        }


        public IEnumerable<TechCrunchcontinentalUSA> ReadCSVData()
        {
            //Declare variables
            IEnumerable<TechCrunchcontinentalUSA> _techCrunchcontinentalUSAs = null;
            HttpWebRequest _httpWebRequest = null;
            HttpWebResponse _httpWebResponse =null;
            StreamReader _streamReader = null;
            CsvReader _csvReader = null;

            //Make request to URL and retrieve data from csv.
            _httpWebRequest = (HttpWebRequest)WebRequest.Create(this.url);
            _httpWebResponse = (HttpWebResponse) _httpWebRequest.GetResponse();
            _streamReader = new StreamReader(_httpWebResponse.GetResponseStream());
            _csvReader = new CsvReader(_streamReader, CultureInfo.InvariantCulture);
            _techCrunchcontinentalUSAs = _csvReader.GetRecords<TechCrunchcontinentalUSA>();

            //return 
            return _techCrunchcontinentalUSAs;
        }
    }
}

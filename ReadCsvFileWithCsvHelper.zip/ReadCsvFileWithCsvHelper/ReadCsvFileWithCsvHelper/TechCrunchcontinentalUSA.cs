﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadCsvFileWithCsvHelper
{
    class TechCrunchcontinentalUSA
    {
        public string permalink { get; set; }
        public string company { get; set; }
        public string numEmps { get; set; }
        public string category { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string fundedDate { get; set; }
        public string raisedAmt { get; set; }
        public string raisedCurrency { get; set; }
        public string round { get; set; }

    }
}
